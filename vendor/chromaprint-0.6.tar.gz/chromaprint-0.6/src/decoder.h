#ifndef CHROMAPRINT_DECODER_H_
#define CHROMAPRINT_DECODER_H_

namespace Chromaprint
{

	class Decoder
	{
	public:
		
	};

};

#endif
